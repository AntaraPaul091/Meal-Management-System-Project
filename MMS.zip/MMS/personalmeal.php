<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
		
	       if(isset($_GET['name'])){
            $name = $_GET['name'];
        }
		
		
		
        include('includes/header.php');
        include('includes/menu.php');
?>



<div id="content" class="view">




    <h2> <?php echo $name;?>'s Meal Details </h2>
    <table id="view">
	<tr>
			  <td>Serial</td>
			  <td>Date</td>
			  <td>meal</td>
			  <td>Type of meal</td>
        
			  
	</tr>
	
	
    <?php
        include('settings/connection.php');
		
		
        

	

	
	$sql = "SELECT date,meal,type FROM date WHERE `name` = '$name'";

        $result = mysqli_query($connect,$sql);
		$i=0;
        if($result){
            while($row = mysqli_fetch_array($result)){
			
			$i++;
    ?>
        <tr>
		
			        <td><?php echo $i;?></td>
			        <td><?php echo $row['date']; ?>
              <td><?php echo $row['meal']; ?></td>
			  <td><?php echo $row['type']; ?></td>
              
          
        </tr>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </table>
   
			
	
				
				
				
 </div>

   
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                