<?php


    session_start();
    if(isset($_SESSION['currentUser'])){
    include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');
    if(isset($_POST['submit'])){
        
        $id = $_POST['id'];
        $name = $_POST['name']; 
        $date = $_POST['date'];
		$bazar = $_POST['bazar'];
        $sample = $_POST['sample'];
		
		
       // move_uploaded_file($tmp_picture,$target.$picture);
       /* if($name==""||$amount==""||$phone==""||$picture==""){
            $error="Error: Fields Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"add.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }else{*/
            $sql = "insert into meal(id,name,date,bazar,sample) values('".$id."','".$name."','".$date."','".$bazar."','".$sample."')";
            $result = mysqli_query($connect,$sql);
            if($result){
                $error = "Information Inserted Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"bazar.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }else{
                $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"bazar.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        //}    
    }
    
?>
    
        <h2>Bazar Entry</h2>

    <style type="text/css">
        
#bazar
{
    overflow: hidden;


}


    </style>


        <form action="bazar.php" method="post">
            <table>
			<tr>
                    <td>BazarCode:</td>
                    <td><input type="text" name="id" /></td>
					
			</tr>
		    <tr>
			
			<td><p style="color:#FF0000";>Dont try this Code above</p></td>
					<td>(<?php
	$sql = "select id from meal";
	$result =  mysqli_query($connect,$sql); 
	if($result){
	
            while($row = mysqli_fetch_array($result)){
		  echo ",". $row['id'];
    
     
            }
         }else
            echo "Query Error";
     
	 ?>)</td>
                </tr>
                <tr>
                    <td> The Person who went to market: </td>
                    <td><select name="name">									
								<?php 	
	$sql = "select name from member";
	$result =  mysqli_query($connect,$sql); 
	if($result){
	
            while($row = mysqli_fetch_array($result)){
				
				?> <option> <?php echo $row['name']; ?> </option> <?php
				
			} 
			
			
			
			
	}  ?>
				
				
				
				
			
									
									
									
									
							</select></td>
                </tr>
                <tr>
                    <td>Date: </td>
                    <td><input type="date" name="date" /></td>
                </tr>
                 <tr>
                    <td>Sample of Bazar: </td>
                    
                   <td> 
                       <textarea name="sample" rows="4" cols="30"></textarea>
                   </td>
                </tr>
                 <tr>
                    <td>Amount: </td>
                    <td><input type="text" name="bazar" /></td>
                </tr>
                
                
                 
                <tr>
                    <td colspan="1"><input type="submit" name="submit" value="Save"/></td>
                    <td colspan="1"><input type="reset" value="Reset"/></td>
                </tr>
            </table>
            
        </form>

	
	
	

<?php 
    include('includes/footer.php');
    }
    else
    header('location:login.php');
?>