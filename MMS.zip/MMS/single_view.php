<?php
    session_start();
	$cost = 0;
    if(isset($_SESSION['currentUser'])){
        $id=0;
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        include('includes/header.php');
        include('includes/menu.php');
?>

<div id="content" class="single_view">
    <h2>Information</h2>
    <div id="single_view">
    <?php
        include('settings/connection.php');
        $sql = "select * from member where id='$id'";
        $result = mysqli_query($connect,$sql);
		$it =0;
        if($result){
            while($row = mysqli_fetch_array($result)){
			
			$meal = $row['mealno'];
			$balance = $row['amount'];
			$it = $row['id'];
			
			
    ?>
        <table>
            <tr>
                <td><b>Name : </b></td>
                <td><?php echo $row['name'] ?></td>
            </tr>
            <tr>
                <td><b>Amount : </b></td>
                <td><?php echo $row['amount'] ?>tk</td>
            </tr>
            <tr>
                <td><b>Mealno : </b></td>
                <td><?php echo $row['mealno']; ?></td>
            </tr>
			
			<tr>
			
			<td>Meal rate:</td>
			
			<td><?php
					
					 $sql = "select SUM(mealno) from member";
                     $result = mysqli_query($connect,$sql);
					
					if($result)
					{
					 while($row = mysqli_fetch_array($result)){
					 
						
						  $meal_total = $row['SUM(mealno)'];
							 							
					
					 
					 }
					 }
					 
					 else
					 echo"Query error";
					 
					  $sql = "select SUM(bazar) from meal";
        			  $result = mysqli_query($connect,$sql);
					
					if($result)
					{
					 while($row = mysqli_fetch_array($result)){
					 
						
						  $sum = $row['SUM(bazar)'];
						  
						  }
						  
					}
					else
					echo"Query error";
					
						if($meal_total > 0){
						
						$meal_rate = $sum/$meal_total;
						$cost = $meal_rate * $meal;
			
						echo (round($meal_rate,2));}
						
						else
							echo "No meal initialize" ;
							//$cost = "no cost yet";
									
					
					
					?>
			(tk per meal)</td>
			
			</tr>
			
			<tr>
				<td>Total Cost:</td>
				<td><?php echo (round($cost,2)); ?>&nbsp;tk</td>
			
			
			</tr>
			<tr>
			<td>
				<?php
				 $get = $balance- $cost;
				 

				 if($get>0)
				 {
				 
				 ?>
				 
				 <h2 style=" color: #006600;"><?php echo "The member will get:      ", (round($get,2));?> &nbsp;tk</h2> 
				 
				 <?php
				 }
				 
				 else{
				 $get = $get * -1; ?>
				 
				<h2 style=" color:#FF0000;"><?php echo "The member have to pay:   ", (round($get,2)); ?>&nbsp; tk</h2>
				
				<?php 
				
				}
				?>
				
			
				 </td>
				 
			
			
			</tr>
			<tr>
				<td><a onclick = "return confirm_delete() ;"  href="delete.php?id=<?php echo $it; ?>">remove</a></td>
			
			</tr>
			
			
			
			
       
        </table>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </div>
    <a href="view.php" id="back">Back to Pervious Page</a>
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                