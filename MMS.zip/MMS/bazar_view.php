<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        $id=0;
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        include('includes/header.php');
        include('includes/menu.php');
?>

<div id="content" class="single_view">
    <h2>Bazar View</h2>
    <div id="single_view">
    <?php
        include('settings/connection.php');
        $sql = "select * from meal where id='$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result)){
    ?>
        <table>
            <tr>
                <td><b>Name : </b></td>
                <td><?php echo $row['name'] ?></td>
            </tr>
            <tr>
                <td><b>Date : </b></td>
                <td><?php echo $row['date'] ?></td>
            </tr>
            <tr>
                <td><b>Amount : </b></td>
                <td><?php echo $row['bazar']; ?>&nbsp; tk</td>
            </tr>
            <tr>
                <td><b>Bazar List: </b></td>
                <td><textarea rows="10" cols="50"><?php echo $row['sample']; ?></textarea></td>
            </tr>

            <tr>
            	<td><button><a href="bazar_edit.php?id=<?php echo $row['id'] ?>">edit it</a></button></td>
            </tr>
            
        </table>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </div>
    <a href="view.php" id="back">Back to Pervious Page</a>
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                