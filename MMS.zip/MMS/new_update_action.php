<?php session_start();
 
 if (isset($_SESSION['currentUser'])) 
 {
	 
        if(isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];
			
		}
		
		else
		{
			header('location : update.php');
			
			
		}
		
		include('includes/header.php');
        include('includes/menu.php');
        include('settings/connection.php');
		
		
		if(isset($_POST['submit']))
		{
			
			$name = $_POST['name'];
			$amount = $_POST['amount'];
			$phone = $_POST['phone'];
			
			
			if($amount==""||$phone==""||$phone = ""){
            $error="Error: Fields Can not be blank.Please fill all fields.";
            echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br />
			<a href=\"update_action.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
            include('includes/footer.php');
            exit();
			}
			if-else{
           // $sql = " update contact_info set name='".$name."',amount='".$amount."',phone='".$phone."' where id = $id";
            $result = mysql_query(" update contact_info set name='".$name."', amount= '".$amount."', phone= '".$phone."' where id = $id");
            if($result){
                $error = "Information Inserted Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"update_action.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }
			
			else{
				
				echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"update_action.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
			}
			
			
        }
		
		
		
			/* try{
				
				if(empty($_POST['name']))
					throw new Exception('insert the name to update');
				
				if(empty($_POST['phone']))
					throw new Exception('insert the amount to update');
				
				if(empty($_POST['amount']))
					throw new Exception('insert the amount to update');
				
				if(empty($_POST['mealno']))
					throw new Exception('insert the amount to update');
				
				if(empty($_POST['amount']))
					throw new Exception('insert the amount to update');
				
				
				
				
				
				$result = mysql_query("update contact_info set name = '$_POST[name]', phone='$_POST[phone]',amount = '$_POST[amount]' where id = $id");
				
               
                $success_message = "Information updated Successfully !";
                 
                
             
				
			}
			
			catch(Exception $e)
			{
				$error_message = $e-> getMessage(); 
			}
			
			*/
			
			
		}
			
			
	 if(isset($error_message))
	 {echo $error_message;
		}
	 if(isset ($success_message))
	 {echo $success_message;
		}
		
		$result = mysql_query("select * from contact_info where id = $id");
		
		while($row = mysql_fetch_array($result))
		{
			
			$old_amount = $row['amount'];
			$old_name   = $row['name'];
			$old_phone  = $row['phone'];
			
			
		}	
    ?>
	<from action ="add.php" method="post">
	<table>
		<tr>
		
				<td>Name</td>
			
				<td><input type="text" name="name" value="<?php echo $old_name;?>"/></td>
		
		</tr>
		<tr>
				<td>Phone</td>
			
				<td><input type="text" name="phone" value ="<?php echo $old_phone;?>"/></td>
		
		</tr>
		
		
		
		<tr>
                <td>Amount: </td>
                <td><input type="text" name="amount" value ="<?php echo $old_amount;?>"/></td>
        </tr>
		
		<tr>
                <td colspan="2"><input type="submit" name="submit" value="Save" id="add"/></td>
                <td colspan="2"><input type="reset" value="Reset" id="reset"/></td>
        </tr>
		
	</table>
	
	    <input type="hidden" name="id" value="<?php echo $id;?>"
		
	</from>	
	
		<?php
		
		
}?>