<?php
		session_start();
		
		if(isset($_SESSION['currentUser']))
		{
			include('includes/header.php');
            include('includes/menu.php');
			include('settings/connection.php');
	
			
			
				
				$sql = "delete from `meal`";
				$result = mysql_query($sql,$connect);
				
				if($result)
				{   
					$error="DONE!!";
					 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br />
			         <a href=\"bazar_list.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                     include('includes/footer.php');
                     exit();
				}
				else
				{
					$error="Cant delete this!";
					echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br />
			        <a href=\"bazar_list.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                    include('includes/footer.php');
                    exit();
				}
			
			
		}
		else
        header('location:login.php');





?>