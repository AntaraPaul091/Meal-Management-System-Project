<?php


    session_start();
    $error="";
?>

<html>
<head>
<title>mms</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<style>

#con{
	
		
	margin : 0 auto;
	display: block;
	width : 900px;
	min-height : 400px;
}

.table{
	
	width : 900px;
	
}



.bt{
	
	background-color : red;
	width :250px;
	color : #fff;
	border-radius: 10px;
	cursor : pointer;
	height: 90px;
	margin : 35px -130px;
	position : relative;
	top :20%;
	left : 50%;
}
.bt:Hover{
	
	background-color : blue;
	
	color : #ffo;
	transition : all .75s ease 0s;
	
}




</style>
</head>

<body>
<?php include('includes/header.php');?>

<div id="con">



<h2 align="center" style="color:#666666" >SELECT YOUR OPTION </h2>

<div style= "width:100%;height:100%">


<a href="login.php"><button class= "bt" type= "button">As a Manager</button></a></li>
<br>
<br>

<a href="st.php"><button class= "bt" type= "button">As a general member</button></a></li>

</div>


</div>
  
  
<?php include('includes/footer.php');
?>

</body>
</html>
