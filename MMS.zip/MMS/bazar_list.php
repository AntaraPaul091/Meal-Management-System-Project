<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        include('includes/header.php');
        include('includes/menu.php');
?>



<div id="content" class="view">




    <h2> Chart of Bazar</h2>
    <table id="view">
	<tr>
			  <td>Serial</td>
			  <td>Bazar Code</td>
        <td>Name</td>
			  <td>Bazar Date</td>
        <td>Bazar Cost</td>
        <td>Edit</td>
			  
	</tr>
	
	
    <?php
        include('settings/connection.php');
        //$sql = "select * from meal";

      $sql = "SELECT * FROM `meal` \n"
    . "ORDER BY `meal`.`date` ASC";

        $result = mysqli_query($connect,$sql);
		$i=0;
        if($result){
            while($row = mysqli_fetch_array($result)){
			
			$i++;
    ?>
        <tr>
		
			        <td><?php echo $i;?></td>
			        <td><?php echo $row['id'] ?>
              <td><?php echo $row['name'] ?></td>
              <td><?php echo $row['date'] ?></td>
              <td><?php echo $row['bazar']?></td>
              <td><a href="bazar_view.php?id=<?php echo $row['id'] ?>">Details</a></td> 
          
        </tr>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </table>
    <style type="text/css">
a{

      text-decoration: none;
      align-items: center;
    }
    </style>
    <script>
           function confirm_delete()
           {
            return confirm ('Are you sure to remove the list?');
           }
           </script>
		   <div id="login_form">
        <h2>Search Individual Bazar</h2>
        <form action="person.php" method="GET" id="login-form">
       
			<table>
                 <tr>  <td> <h4 align= "center"> Total Days of Bazar </h4></td><td> <select name="name">
                   									
								<?php 	
	$sql = "select name from member";
	$result =  mysqli_query($connect,$sql); 
	if($result){
	
            while($row = mysqli_fetch_array($result)){
				
				
				?> <option> <?php echo $row['name']; ?> </option> <?php
				
			} 
			
			
			
			
	}  ?>
				
				
				
				
			
									
									
									
									
							</select></td></tr>
                
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<br />
			
            
			
			</table>
			<input type="submit" name="submit" value="Submit" />
			
			
        </form>
    </div>

   <button> <a onclick = "return confirm_delete() ;"  href="remove.php">Erase Bazar</a></button>
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                