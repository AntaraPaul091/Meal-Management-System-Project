<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        include('includes/header.php');
        include('includes/menu.php');
?>

<div id="content" class="view">
    <h2>Meal</h2>
    <table id="view">
		<tr>
            <td>NAME</td>
            <td>MEAL NUMBER</td>
            <td>MEAL INSERTION</td>
			<td>Bazar</td>
        </tr>	
	
    <?php
        include('settings/connection.php');
        $sql = "select * from member";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result)){
    ?>
        <tr>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['mealno'] ?></td>
            <td><a href="meal_action.php?id=<?php echo $row['id']; ?>">Insert Meal</a></td>
			<td><a href="bazar.php">Bazar Cost</a></td>
        </tr>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </table>
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                