<!doctype html>
<html lang="en">
    <head>
        <title>MMS</title>
        <link rel="stylesheet" href="style.css" type="text/css" />

        <script>
           function confirm_delete()
           {
            return confirm ('Are you sure to delete this record');
           }
           </script>
      
		<style>
		<!--
				.style1 {
	font-size: 36px;
	color: #99CCCC;
	font-style: inherit;
}
		-->



    a{

      text-decoration-style: none;
    }
		</style>
    </head>
    <body>
       <table bgcolor="#CCCCCC" bordercolor="#00FFCC" width="100%" border="12" cellspacing="10" cellpadding="20" >
  <tr>
    <th  bgcolor="#0099CC" scope="col"><span class="style1">MEAL MANAGEMENT SYSTEM</span></th>
  </tr>
</table>