<br />
<br />
<br />
<div id="footer">
                   
					 <h4> Manager : <?php $i=0;
					 
					 if(isset($_SESSION['currentUser']))
						 
						{
							echo '<front color = "red">' .$_SESSION['currentUser'].'</front>'?> </br></br><a href="includes/logout.php", >
							
						<?php
						
							echo "logout";
							
							
							
						}
						
				 else
				 {
					 echo "None login yet";
					 
					 ?> </br></br><a  href="index.php">
					 
					 <?php
						
					
				 echo'<front color = "red">' ."Home". '</front>';
				 
				 }



?></a></h4> 
					 
					
</div>
            </div>
        </div>
    </body>
</html>