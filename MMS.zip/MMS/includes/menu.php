 <div id="menu">
                    <ul>
                        <li><a href="index1.php">Home</a></li>
                        <li><a href="add.php">Add member</a></li>
                        <li><a href="update.php">Update Account</a></li>
                  		<li><a href="meal.php">Meal Reservation</a></li>
						<li><a href="bazar_list.php">Bazar List</a></li>
						<li><a href="view.php">Summary of the Mess</a></li>
						<li><a href="meal_information.php">Meal Information</a></li>
                    </ul>
                </div>