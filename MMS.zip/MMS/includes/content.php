  </br>
 
		               
                <div id="content">
                   <h2 align = "center">Create a new manager account</h2>
				   <a align= "center", href="creat.php"><h2 color ="red";>*click Here*</h2></a>
                </div>