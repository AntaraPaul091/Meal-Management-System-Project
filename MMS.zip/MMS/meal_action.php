
<?php

    session_start();
    if(isset($_SESSION['currentUser'])){
	
	$id=0;
	if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
	
	include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');

    if(isset($_POST['submit'])){
	
	 $sql = "select * from member where id= '$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result))
			{  
			$name = $row['name'];
			$mealno_old = $row['mealno'];
			}
			
			}
			
			else
            echo "Query Error";
   
      
	   
		$mealno = $_POST['mealno'] + $mealno_old;
		$date = $_POST['date'];
		$other = $_POST['other'];
		
		
		
        if($mealno==""){
            $error="Error: name Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"meal.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }else{
		
		
           
			
			$sql = "UPDATE `member` SET `mealno` = $mealno WHERE `member`.`id` = $id";
			
			
			
			$sqll = "INSERT INTO `date` (`id`, `name`, `date`, `meal`,`type`) VALUES ('', '$name', '$date', '$_POST[mealno]','$other')";
			
			
			
			$res = mysqli_query($connect,$sqll);
			
			
            $result = mysqli_query($connect,$sql);
            if($result){
				
				if($res){
                $error = $name."'s meal Inserted Successfully ! Total meal of ".$name." is ".$mealno;
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"meal.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();}
				 
				 else{
					 
					  $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"meal.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
					 
					 
				 }
				 
            }else{
                $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"meal.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        }    
    }
    
?>

</ br>
<div id="content">
  
	<?php
        include('settings/connection.php');
        $sql = "select * from member where id= '$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result))
			
			{  
			
			
			$mealno_old = $row['mealno'];
			
			?>
	</ br>
        <h2> <?php echo $row['name']?>'s meal insertion</h2>
        <form action="" method="post" id="login-form">
            <table>
			
	
    
	
	
				
                <tr>
                    <td>Name: </td>
                    <td><?php echo $row['name'];?></td>
                </tr>
                 <tr>
                    <td> Present Meal No: </td>
                    <td><?php echo $row['mealno'];?></td>
                    
                </tr>
				 <tr>
                    <td> Date: </td>
                    <td><input type="date" name="date" value=""/></td>
                    
                </tr>
				 <tr>
                    <td> Insert Meal No: </td>
                    <td><input type="text" name="mealno" value=""/></td>
                    
                </tr>
				
				 <tr>
                    <td> optional: </td>
                    <td><select name ="other"><option>own</option>
					<option>own and guest</option>
					<option>only guest</option></select></td>
                    
                </tr>
				
               
                
                 
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Save" id="add"/></td>

                </tr>
            </table>
			
			<!--<input type="hidden" name="id" value="<?php echo $id;?>-->
            
        </form>
    
</div>

 <?php
            }
         }else
            echo "Query Error";
 
 include('includes/footer.php');
 
	}else
    header('location:login.php');
?>