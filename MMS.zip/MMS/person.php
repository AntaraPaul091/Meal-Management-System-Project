<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
		
	       if(isset($_GET['name'])){
            $name = $_GET['name'];
        }
		
		
		
        include('includes/header.php');
        include('includes/menu.php');
?>



<div id="content" class="view">




    <h2> <?php echo $name;?>'s Bazar List </h2>
    <table id="view">
	<tr>
			  <td>Serial</td>
			  <td>Bazar Code</td>
			  <td>Bazar Date</td>
        <td>Bazar Cost</td>
        <td>Edit</td>
			  
	</tr>
	
	
    <?php
        include('settings/connection.php');
		
		
	$sql = "SELECT `id`, `date`,`bazar`,`sample` FROM `meal` WHERE `name` = \"$name\"";

        $result = mysqli_query($connect,$sql);
		$i=0;
        if($result){
            while($row = mysqli_fetch_array($result)){
			
			$i++;
    ?>
        <tr>
		
			        <td><?php echo $i;?></td>
			        <td><?php echo $row['id']; ?>
              <td><?php echo $row['date']; ?></td>
              <td><?php echo $row['bazar'];?></td>
              <td><a href="bazar_view.php?id=<?php echo $row['id'] ?>">Details</a></td> 
          
        </tr>
     <?php
            }
         }else
            echo "Query Error";
     ?>
    </table>
   
			
	
				
				
				
 </div>

   
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                