<?php


    session_start();
    if(isset($_SESSION['currentUser'])){
    include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
		$password = $_POST['password'];
		$phone = $_POST['phone'];  
        if($name==""||$password==""||$phone==""){
            $error="Error: Fields Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"creat.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }
	else{
		$sql = "insert into test(name,password,phone) values('".$name."','".$password."','".$phone."')";
            $result = mysqli_query($connect,$sql);
			echo $result;
			
            if($result){
                $error = "Account created Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"index1.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }else{
                $error = "Can not create Account";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"creat.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        }    
    }
    
?>
<div id="content" class = "view">
</br>
	</br>
    
	
        <h2>Please Fill the Information Bellow</h2>
        <form action="creat.php" method="post" id="login-form" enctype="multipart/form-data">
            <table>
                <tr>
                    <td>Username: </td>
                    <td><input type="text" name="name" /></td>
                </tr>
                 <tr>
                    <td>password: </td>
                    <td><input type="text" name="password" /></td>
                </tr>
                <tr>
                    <td>Phone: </td>
                    <td><input type="text" name="phone" /></td>
                </tr>
                
                
                
                 
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Create" id="add"/></td>
                    <td colspan="2"><input type="reset" value="Reset" id="reset"/></td>
                </tr>
            </table>
            
        </form>
    
</div>
<?php 
    include('includes/footer.php');
    }
    else
    header('location:login.php');
?>