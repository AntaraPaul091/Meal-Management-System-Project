<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        include('includes/header.php');
        include('includes/menu.php');
?>

<div id="content" class="view">
    <h2>All member Information</h2>
    <table id="view">
	 <tr>
	 		 <td>Serial</td>
            <td>Member</td>
            <td>Given Amount</td>
			<td>Meal Number</td>
            <td>Check</td>
			 
	 
	 </tr>
    <?php
        include('settings/connection.php');
        $sql = "select * from member";
        $result = mysqli_query($connect,$sql);
        if($result){
			
			$sum = 0;
			$s = 0;
            while($row = mysqli_fetch_array($result)){
			 
			 $old_meal_number = $row['mealno'];
			
			$s++;
	 ?>
	
	 
        <tr>
		    <td><?php echo $s;?></td>
            <td><a href="single_view.php?id=<?php echo $row['id'] ?>"><?php echo $row['name'] ?></a></td>
            <td><?php echo $row['amount'] ?>tk</td>
			<td><?php echo $row['mealno']?></td>
            <td><a href="single_view.php?id=<?php echo $row['id'] ?>">Details</a></td>
        </tr>
		
		
     <?php
            }
         }else
            echo "Query Error";
    
				
				$sum = 0;
				
        $sql = "select SUM(bazar) from meal";
        $result = mysqli_query($connect,$sql);
					
					if($result)
					{
					 while($row = mysqli_fetch_array($result)){
					 
						
						  $sum = $row['SUM(bazar)'];
							 							
					}


					$sql = "SELECT * FROM `meal` WHERE `id` = 1 ORDER BY `date` ASC";
					$result = mysqli_query($connect,$sql);
					
					$date = "The mess is not started yet";
					
					

					 if($result)
					 {
						 

					 		while($row=mysqli_fetch_array($result))
					 		{

					 				$date = $row['date'];

					 		}

					 }
					 
					 else{
						 
					 $date = "The mess is not started yet";
					 }
					 
										
					
					
					?>
  </table>
					</br>
					
					
					
					<table bgcolor="#009999" cellpadding="3" cellspacing="6" border="8" align="center">
					 <tr>
	 
	                      <td bgcolor="#CC3300"><h2>The total Bazar Cost: <?php echo $sum;?>tk</h2></td>
					</tr>
					 <tr>
	 
	                      <td bgcolor="#CC3300"><h2>Mess start From: <?php echo $date;?></h2></td>
					</tr>
					 <tr>
	 
	                      <td bgcolor="#FF0000" ><h2>The total Border: <?php echo $s;?></h2></td>
					</tr>
					
					
					
					
					</table>
				
					
					
					<?php
					
					 $sql = "select SUM(mealno) from member";
                     $result = mysqli_query($connect,$sql);
					
					if($result)
					{
						$meal_total = 0;
					 while($row = mysqli_fetch_array($result)){
					 
						
						  $meal_total = $row['SUM(mealno)'];
							 							
					
					 
					 }
					 }
					 
					 else
					 "Query error";
				 
				 
					 
					 	if($meal_total != 0)
						{
							
						
						$meal_rate = $sum/$meal_total;   
						?>
							
					
					<table bgcolor="#009999" cellpadding="3" cellspacing="6" border="8" align="center">
					 <tr>
	 
	                      <td bgcolor="#CC3300"><h2>The meal rate: <?php echo (round($meal_rate,2));?>&nbsp;tk</h2></td>
					</tr>
					
					<?php
					}
					else{
					
					
					
				 ?><table bgcolor="#009999" cellpadding="3" cellspacing="6" border="8" align="center">
                    <tr>
	 
	                      <td bgcolor="#CC3300"><h2><?php   echo "meal rate now 0";?>&nbsp;tk</h2></td>
					</tr>						
					</table >
					<?php
					
					}	  
					
					 $sql = "select SUM(amount) from member";
                     $result = mysqli_query($connect,$sql);
					  $amount_total = 0;
					
					if($result)
					{
					 while($row = mysqli_fetch_array($result)){
					 
						
						  $amount_total = $row['SUM(amount)'];
						  
						  
						  ?>
							
					
					<table bgcolor="#009999" cellpadding="3" cellspacing="6" border="8" align="center">
					 <tr>
	 
	                      <td bgcolor="#CC3300"><h2>The Total Given Amount : <?php echo $amount_total ;?>tk</h2></td>
					</tr>
					<tr>
	 
	                      <td bgcolor="#CC3300"><h2>The total Rest Amount: <?php echo $amount_total-$sum ;?>tk</h2></td>
					</tr>
					
					
					<?php
							 							
					
					 
					 }
					 }
					 
					 else
					 "Query error";
					
					
			         ?>
					</table>
					
					<?php
					}
					
					//include('settings/connection.php');
        			//$sql = "select * from meal";
					//$result = mysql_query($sql,$connect);
		
				if($result)
					{
					
					 while($row = mysqli_fetch_array($result)){
					 
				?>
	
	 

		
     <?php
	 }
	 
	 
         }else
            echo "Query Error";
        ?>
		 
				
	
	
	</table>
	
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                