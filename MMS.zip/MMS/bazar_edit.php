
<?php

    session_start();
    if(isset($_SESSION['currentUser'])){


	
	$id=0;
	if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
	
	include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');
    
    if(isset($_POST['submit'])){
	
	 $sql = "select * from meal where id= '$id'";
        $result = mysql_query($sql,$connect);
        if($result){
            while($row = mysql_fetch_array($result))
			{  
			
			$bazar_old = $row['bazar'];
			}
			
			}
			
			else
            echo "Query Error";
   
      
	   
		$bazar = $_POST['bazar'] ;
        $sample = $_POST['sample'];
		
		
		
        if($bazar==""){
            $error="Error: bazar amount Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"meal.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }else{
		
		
            //$sql = "insert into contact_info(mealno) value('".$mealno."') where id = $id";
			
			/*
			$sql = "update contact_info 
			set mealno = '$_POST[mealno]'
			where id = $id" ;
			*/
			
			//$sql = "UPDATE `contact_info` SET `mealno` = '".$mealno."' WHERE `contact_info`.`id` = $id ; "
			
			//$sql = "UPDATE `meal` SET `bazar` = $bazar, `sample` =  $sample WHERE `meal`.`id` = $id";

            $sql = "UPDATE `meal` SET `bazar` = '$bazar', `sample` =  '$sample' WHERE `meal`.`id` = $id";
			
			//$sql = "UPDATE `contact_info` SET `phone` = '', `amount` = '' WHERE `contact_info`.`id` = $id";
			
			
			
			
            $result = mysql_query($sql,$connect);
            if($result){
                $error = "Information Inserted Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"bazar_list.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }else{
                $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"bazar_list.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        }    
    }
    
?>

</ br>
<div id="content">
    
	</ br>
        <h2>Edit Bazar Information</h2>
        <form action="" method="post" id="login-form">
            <table>
			
	<?php
        include('settings/connection.php');
        $sql = "select * from meal where id = '$id'";
        $result = mysql_query($sql,$connect);


        if($result){
            while($row = mysql_fetch_array($result))
			
			{  
			
			
			$bazar_old = $row['bazar'];
			
			?>
    
	
	
				<tr>
                    <td>Id: </td>
                    <td><?php echo $id;?></td>
                </tr>
                <tr>
                    <td>Name: </td>
                    <td><?php echo $row['name'];?></td>
                </tr>
                <tr>
                    <td>Date: </td>
                    <td><?php echo $row['date'];?></td>
                </tr>
                <tr>
                    <td>Sample: </td>
                    <td><textarea name="sample" rows="4" cols="30"><?php echo $row['sample']; ?></textarea></td>
                </tr>
                 <tr>
                    <td>Amount: </td>
                    <td><input type="text" name="bazar" value="<?php echo $row['bazar']; ?>"/></td>
                </tr>
               
                
                 
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Save" id="add"/></td>
                    <td colspan="2"><input type="reset" value="Reset" id="reset"/></td>
                </tr>
            </table>
			
			<input type="hidden" name="id" value="<?php echo $id;?>" />
            
        </form>

       
</div>

<div id="delete">

<style type="text/css">
a{

      text-decoration: none;
    }
    </style>

       <h2>Do you want to delete this record?</h2>
       <script>
           function confirm_delete()
           {
            return confirm ('Are you sure to delete this record');
           }
           </script>
             <button> <a text-decoration: none onclick = "return confirm_delete() ;"  href="detete_bazar.php?id=<?php echo $row['id'];?>">Delete Record</a></button>
  </div>

        <?php
            }
         }else
            echo "Query Error";


    include('includes/footer.php');




 
	}else
    header('location:login.php');
?>