<?php


    session_start();
    if(isset($_SESSION['currentUser'])){
    include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');
    if(isset($_POST['submit'])){
        
        $name = $_POST['name'];
		$date = $_POST['date'];
		$mealno = $_POST['mealno'];
       
		
        if($name==""||$mealno==""||$date==""){
            $error="Error: Fields Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"add.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }else{
            $sql = "insert into bazar(name,date,mealn) values('".$name."','".$date."','".$mealno."')";
            $result = mysql_query($sql,$connect);
            if($result){
                $error = "Information Inserted Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"add.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }else{
                $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"add.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        }    
    }
    
?>
<div id="content">
    <div id="contact-form">
        <h2>Please Fill the Information Bellow</h2>
        <form action="add_meal.php" method="post" id="login-form" enctype="multipart/form-data">
            <table>
                <tr>
                    <td>Name: </td>
                    <td><input type="text" name="name" /></td>
                </tr>
                 <tr>
                    <td>Date: </td>
                    <td><input type="text" name="date" /></td>
                </tr>
                <tr>
                    <td>Meal: </td>
                    <td><input type="text" name="mealno" /></td>
                </tr>
                
               
                
                 
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Save" id="add"/></td>
                    <td colspan="2"><input type="reset" value="Reset" id="reset"/></td>
                </tr>
            </table>
            
        </form>
    </div>
</div>
<?php 
    include('includes/footer.php');
    }
    else
    header('location:login.php');
?>