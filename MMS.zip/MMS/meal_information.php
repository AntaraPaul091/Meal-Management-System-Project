<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        include('includes/header.php');
        include('includes/menu.php');
		include('settings/connection.php');
?>



<div id="content" class="view">
        


   
    
		   <div id="login_form">
        <h2>Explore Individual Meal</h2>
        <form action="personalmeal.php" method="GET" id="login-form">
       
			<table>
                 <tr>  <td> <h4 align= "center"> List of dates : </h4></td><td> <select name="name">
                   									
								<?php 	
	$sql = "select name from member";
	$result =  mysqli_query($connect,$sql); 
	if($result){
	
            while($row = mysqli_fetch_array($result)){
				
				
				?> <option> <?php echo $row['name']; ?> </option> <?php
				
			} 
			
			
			
			
	}  ?>
				
				
				
				
			
									
									
									
									
							</select></td></tr>
                
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<br />
			
            
			
			</table>
			<input type="submit" name="submit" value="Submit" />
			
			
        </form>
		<style type="text/css">
a{

      text-decoration: none;
      align-items: center;
    }
    </style>
    <script>
           function confirm_delete()
           {
            return confirm ('Are you sure to remove the list?');
           }
           </script>
    </div>
	
	<button> <a onclick = "return confirm_delete() ;"  href="mealdelete.php">Erase meal list</a></button>

   
</div>

<?php        
        include('includes/footer.php');
    }else
        header('location:login.php');
?>
               
                
                