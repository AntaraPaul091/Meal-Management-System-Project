<?php

    session_start();
    $error="";
?>

        <?php
		 include('includes/header.php');
    if(isset($_POST['submit'])){
         $userName = $_POST['username'];
         $passWord = $_POST['password'];
        if($userName==""|| $passWord==""){
            echo "<div id=\"content\"><script>alert('You must fill all fields');".$error."</script><a href=\"login.php\" style=\"display:block;margin-top:150px;;text-align:center;font-size:18px;color:red;\">Go Back to Log In Page</a></div>";
            include('includes/footer.php');
            exit();
        }else{
            include('settings/connection.php');
            //$userName = mysql_real_escape_string($userName);
           // $passWord = mysql_real_escape_string($passWord);
            $sql = "select * from test where username='$userName' and password='$passWord'";
            $result = mysqli_query($connect,$sql);
            if($result){
                $count = mysqli_num_rows($result);
            }else
                echo "Query Error";
            if($count==1){
                $_SESSION['currentUser']=$userName;
                header('location:index1.php');
            }else{
               echo "<div id=\"content\"><script>alert('Invalid Login Information');".$error."</script><a href=\"login.php\" style=\"display:block;margin-top:150px;;text-align:center;font-size:18px;color:red;\">Go Back to Log In Page</a></div>";
               include('includes/footer.php');
               exit();
            }        
        }
    }
?>
<div id="content">
    <div id="login_form">
        <h2>Fill the information for login</h2>
        <form action="login.php" method="post" id="login-form">
            <input type="text" name="username" placeholder="username" /> <br />
            <input type="password" name="password" placeholder="password" /> <br />
            <input type="submit" name="submit" value="Log In" />
        </form>
    </div>
</div>
<?php include('includes/footer.php');