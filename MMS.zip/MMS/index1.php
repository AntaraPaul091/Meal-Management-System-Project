<?php
    session_start();
    if(isset($_SESSION['currentUser'])){
        include('includes/header.php');
        include('includes/menu.php');
        include('includes/content.php');
        include('includes/footer.php');
		
	
		
		
    }else
        header('location:login.php');
?>
               
                
                