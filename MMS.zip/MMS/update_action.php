
<?php

    session_start();
    if(isset($_SESSION['currentUser'])){
	
	$id=0;
	if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
	
	include('includes/header.php');
    include('includes/menu.php');
    include('settings/connection.php');
    if(isset($_POST['submit'])){
	
	 $sql = "select * from member where id= '$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result))
			{  
			
			$name = $row['name'];
			
			$amount_old = $row['amount'];
			
			}
			
			}
			
			else
            echo "Query Error";
   
      
	   
		$amount = $_POST['amount'] + $amount_old;
		//
		
		
		
       /* if($amount==""){
            $error="Error: amount Can not be blank.Please fill all fields.";
             echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"update.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
             include('includes/footer.php');
             exit();
        }else{*/
		
		
           
			
			$sql = "UPDATE member SET  amount = '$amount' WHERE id = '$id'";
			
			//$sql = "UPDATE `member` SET  `amount` = '$amount' WHERE `member`.`id` = $id";
			
			
			
			
            $result = mysqli_query($sql,$connect);
            if($result){
                $error = $name."'s Account Updating Successfully !";
                 echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"update.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                 include('includes/footer.php');
                 exit();
            }else{
                $error = "Information is not inserted";
                echo "<div id=\"content\"><center style=\"margin-top:150px;color:red;font-weight:bold;\">".$error."</center><br /><a href=\"update.php\" style=\"display:block;text-align:center;font-size:18px;color:red;\">Go Back to Previous Page</a></div>";
                include('includes/footer.php');
                exit();
            }    
        //}    
    }
    
?>

<div id="content">

		<?php
        include('settings/connection.php');
        $sql = "select * from member where id= '$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            while($row = mysqli_fetch_array($result))
			
			{  
			
			
			$mealno_old = $row['mealno'];
			
			?>

   
		
		<br>
		<br>
        <h2>Updating <?php echo $row['name'];?>'s Account</h2>
        <form action="" method="post" id="login-form">
            <table>
			
	
          		<tr>
                    <td>Name: </td>
                    <td><b><?php echo $row['name'];?></b></td>
                </tr>
				
                 <tr>
                    <td>Amount Given: </td>
					
                    <td><b><?php echo $row['amount'];?></b>tk</td>
					
                </tr>
				<br>
				<br>
				 <tr>
                    <td>Amount to be Added:</td>
					
                    <td><input type="text" name="amount" value=""/></td>
					<td>tk</td>
                </tr>
				 
               
                
                 
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Save" id="add"/></td>
					<td></td>
                    <td colspan="2"><input type="reset" value="Reset" id="reset"/></td>
                </tr>
				
            </table>
			
			<td><input type="hidden" name="id" value="<?php echo $id;?>" /></td>
            
        </form>
  
</div>

 <?php
            }
         }else
            echo "Query Error";
 
 include('includes/footer.php');
 
	}else
    header('location:login.php');
?>