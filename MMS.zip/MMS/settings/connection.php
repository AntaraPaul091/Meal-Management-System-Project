<?php
	$connect = mysqli_connect("localhost","root","","antora") or die("Cant connect to database");
    
	//mysqli_select_db("antora",$connect) or die('database doesnt exist');
?>
